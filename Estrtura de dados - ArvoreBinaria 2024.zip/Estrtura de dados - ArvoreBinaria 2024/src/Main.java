public class Main {
    public static void main(String[] args) {
        ArvoreBi arvoreBi = new ArvoreBi();

        arvoreBi.inserir(37);
        arvoreBi.inserir(59);
        arvoreBi.inserir(48);
        arvoreBi.inserir(45);
        arvoreBi.inserir(7);
        arvoreBi.inserir(-3);

        System.out.println("arvore binaria");
        arvoreBi.preOrdem(arvoreBi.getRaiz());

        System.out.println("o numero foi removido");
       arvoreBi.remover(37);

        System.out.println("arvore binaria");
        arvoreBi.preOrdem(arvoreBi.getRaiz());


       // System.out.println("arvore binaria");
        //arvoreBi.posOrdem(arvoreBi.getRaiz());

        //System.out.println("o numero foi removido");
        //arvoreBi.remover();

        //arvoreBi.posOrdem(arvoreBi.getRaiz());
    }
}