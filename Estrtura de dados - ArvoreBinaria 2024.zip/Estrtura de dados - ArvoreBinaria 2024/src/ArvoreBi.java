public class ArvoreBi {
    private No raiz;

    public ArvoreBi() {
        this.raiz = null;
    }

    public No inserir(int valor) {
        No novoNo = new No(valor);
        if (this.raiz == null) {
            this.raiz = novoNo;
        } else {
            No atual = this.raiz;
            No pai = null;
            while (atual != null) {
                if (novoNo.getValor() < atual.getValor()) {
                    pai = atual;
                    atual = atual.getEsq();
                } else {
                    pai = atual;
                    atual = atual.getDir();
                }
            }
            if (novoNo.getValor() < pai.getValor()) {
                pai.setEsq(novoNo);
            } else {
                pai.setDir(novoNo);
            }
        }
        return novoNo;
    }

    public void preOrdem(No no) {
        if (no == null) {
            return;
        }
        System.out.println(no.getValor());
        preOrdem(no.getEsq());
        preOrdem(no.getDir());
    }

    public void emOrdem(No no) {
        if (no == null) {
            return;
        }
        emOrdem(no.getEsq());
        System.out.println(no.getValor());
        emOrdem(no.getDir());
    }

    public void posOrdem(No no) {
        if (no == null) {
            return;
        }
        posOrdem(no.getEsq());
        posOrdem(no.getDir());
        System.out.println(no.getValor());
    }

    public No getRaiz() {
        return this.raiz;
    }

    public boolean remover(int valor) { //atual repersenta o no que esta sendo verificado no momento, começa pela raiz, pai é o no pai do nó atual, que incia como null
        No atual = this.raiz;
        No pai = null;
        boolean FilhoEsq = true;
        //uma função boolean que indica se o atual é o filho esquerdo do pai, no inicio assume que ele é o filho esq.

        // Escolha 1: Esse comando encontra o no a ser removida e seu pai
        while (atual != null && atual.getValor() != valor) {
            pai = atual;
            if (valor < atual.getValor()) {
                atual = atual.getEsq();
                FilhoEsq = true;
            } else {
                atual = atual.getDir();
                FilhoEsq = false;
            }
        }

        if (atual == null) {
            return false; // Caso o no não for encontrado
        }

        // Escolha 2: No que queremos remover nao possui filhos
        if (atual.getEsq() == null && atual.getDir() == null) {
            if (atual == this.raiz) {
                this.raiz = null;
            } else if (FilhoEsq) {
                pai.setEsq(null);
            } else {
                pai.setDir(null);
            }
        }
        // Escolha 3: No que queremos remover possui um filhos
        else if (atual.getDir() == null) { // Possui apenas filhos a esquerda
            if (atual == this.raiz) {
                this.raiz = atual.getEsq();
            } else if (FilhoEsq) {
                pai.setEsq(atual.getEsq());
            } else {
                pai.setDir(atual.getEsq());
            }
        } else if (atual.getEsq() == null) { // Possui apenas filhos a direita
            if (atual == this.raiz) {
                this.raiz = atual.getDir();
            } else if (FilhoEsq) {
                pai.setEsq(atual.getDir());
            } else {
                pai.setDir(atual.getDir());
            }
        }
        // Escolha 4: Nó que queremos remover possui dois filhos
        else {
            No substituto = atual.getDir();
            No paiSubstituto = atual;

            // Ver qual vai ser o substituto (o valor menor da subárvore direita)
            while (substituto.getEsq() != null) {
                paiSubstituto = substituto;
                substituto = substituto.getEsq();
            }

            // Substituir o nó a ser removido pelo substituto
            if (substituto != atual.getDir()) {
                paiSubstituto.setEsq(substituto.getDir());
                substituto.setDir(atual.getDir());
            }

            if (atual == this.raiz) {
                this.raiz = substituto;
            } else if (FilhoEsq) {
                pai.setEsq(substituto);
            } else {
                pai.setDir(substituto);
            }

            substituto.setEsq(atual.getEsq());
        }
        return true;
    }

}
